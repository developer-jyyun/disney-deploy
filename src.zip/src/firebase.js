// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyApxpX5hl-MNmU8H_jKaN5eu5F4Z3zaGAM",
  authDomain: "diseneyplus-ffe32.firebaseapp.com",
  projectId: "diseneyplus-ffe32",
  storageBucket: "diseneyplus-ffe32.appspot.com",
  messagingSenderId: "642842908233",
  appId: "1:642842908233:web:b814142517133efb961198",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;
